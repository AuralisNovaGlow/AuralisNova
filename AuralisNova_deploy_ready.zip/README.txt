AuralisNova - Deploy-ready Fullstack App
----------------------------------------

What this contains:
- backend/        : Node.js + Express server, routes, and OpenAI AI integration.
- frontend/       : React app (Create React App structure minimal files included).
- .env.template   : Template for environment variables.
- package.json    : Root scripts for building and starting the whole app.
- Server is configured to serve the React build so you can deploy the whole project as one service.

Quick local steps:
1. Copy .env.template to .env and fill values (DO NOT commit .env to GitHub).
2. In the project root:
   - npm install
   - npm run build   (this installs frontend deps and builds the React app)
   - npm start       (starts express server at process.env.PORT or 5000)
3. For production deployment, push repo to GitHub and connect to Render (or Railway).
   - Build Command: npm run build
   - Start Command: npm start
   - Add environment variables in the Render dashboard: MONGO_URI, JWT_SECRET, OPENAI_API_KEY

Important notes:
- Replace placeholder values in .env before deployment.
- The AI route uses OpenAI's chat completions endpoint and expects OPENAI_API_KEY in env.
