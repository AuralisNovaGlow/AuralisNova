const express = require('express');
const router = express.Router();
const axios = require('axios');

// Simple health check
router.get('/', (req, res) => res.json({ status: 'ai route working' }));

// Chat endpoint using OpenAI (gpt-4o-mini)
router.post('/chat', async (req, res) => {
  try {
    const userMessage = req.body.message || '';
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: 'OPENAI_API_KEY not set in environment' });
    }

    const payload = {
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are AuralisNova, a friendly helpful AI companion.' },
        { role: 'user', content: userMessage }
      ],
      max_tokens: 800
    };

    const response = await axios.post('https://api.openai.com/v1/chat/completions', payload, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    const content = response.data.choices && response.data.choices[0] && response.data.choices[0].message
      ? response.data.choices[0].message.content
      : 'Sorry, I could not get a response.';

    res.json({ response: content });
  } catch (err) {
    console.error('OpenAI error:', err.message);
    res.status(500).json({ error: 'AI error', details: err.message });
  }
});

// Small helper endpoints
router.get('/decision', (req, res) => {
  const decisions = ['Yes', 'No', 'Maybe', 'Absolutely', 'Think again'];
  res.json({ decision: decisions[Math.floor(Math.random()*decisions.length)] });
});

router.get('/daily', (req, res) => {
  const sparks = ['You are amazing today!', 'Keep pushing forward!', 'Great things are coming!'];
  res.json({ spark: sparks[Math.floor(Math.random()*sparks.length)] });
});

module.exports = router;
