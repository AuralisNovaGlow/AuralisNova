import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [chat, setChat] = useState('');
  const [response, setResponse] = useState('');

  const sendChat = async () => {
    try {
      const res = await axios.post('/api/ai/chat', { message: chat });
      setResponse(res.data.response || JSON.stringify(res.data));
    } catch (err) {
      setResponse('Error: ' + (err.response?.data?.error || err.message));
    }
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>AuralisNova</h1>
      <div style={{ marginBottom: 8 }}>
        <input style={{ padding: 8, width: '60%' }} value={chat} onChange={e => setChat(e.target.value)} placeholder="Say something..." />
        <button style={{ marginLeft: 8, padding: '8px 12px' }} onClick={sendChat}>Send</button>
      </div>
      <div style={{ whiteSpace: 'pre-wrap' }}>{response}</div>
    </div>
  );
}

export default App;
